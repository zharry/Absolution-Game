Painterly Spell Icon set part 4

These icons are released by the artist under the following licenses:
GNU GPL 2.0
GNU GPL 3.0
CC-BY 3.0
CC-BY-SA 3.0

Attribution:

J. W. Bjerk (eleazzaar) -- www.jwbjerk.com/art  -- find this and other open art at: http://opengameart.org


If you find these icons useful, I'd appreciate it if you send me a line, with a link to your project -- just to satisfy my curiosity.
Also I can probably be commissioned to extend or expand this set at a reasonable rate.

Enjoy...

J.W.Bjerk
me AT jwbjerk D0T com


